// Quansah Richmond
// UEB3224522

#include <iostream>

using namespace std;

int main(){
    int next;
    cout << "Welcome to the Text Adventure Game!\n\n";

    do{
    cout << "You are embarking a journey where you find yourself at the bank of a river with three items(Maize,Hawk and Cock)."<<endl;
    cout << "You can only cross the river with one item at a time.\n\n";

    cout << "HINT: You can also return the item back when you cross and come for another.\n\n";

    cout << "Which item do you want to go with first?"<<endl;
    cout << "1. Maize"<<endl;
    cout << "2. Cock"<<endl;
    cout << "3. Hawk \n\n";

    cout << "Please enter the number of your choice: ";
    int choice;
    cin >> choice;

    if(choice == 1){
            cout << "\nAs you went,the hawk grabbed the cock."<<endl;
            cout << "You lost the game! Try Again!"<<endl;
    }

    else if(choice == 2){
        cout<< " \nYou cross the river with the Cock successfully!\n\n";
        cout << "Which one do you want to take for your next journey?"<<endl;\
        cout << "1. Maize"<<endl;
        cout << "2. Hawk \n\n";

        cout << "Please enter the number of your choice: ";
        cin >> choice;

        if(choice == 1){
            cout << "\nYou decide to take the Maize to cross the river.You have cross the river with the Maize successfully!"<<endl;
            cout << "Now you have both the Maize and the Cock at the end of the river."<<endl;
            cout << "Do you want to keep both or return with one? "<<endl;
            cout << "1. Keep both"<<endl;
            cout << "2. Return the Maize"<<endl;
            cout << "3. Return the Cock\n\n";

            cout << "Please enter the number of your choice: ";
            cin >> choice;

            if(choice == 1 ){
                cout << "\nAs you went,the cock pecked at the maize."<<endl;
                cout << "You lost the game!"<<endl;
            }
            else if(choice == 3){
                cout<< "\nYou Return with the Cock successfully\n\n";

            cout << "Which one do you want to take for your next journey?"<<endl;\
            cout << "1. Cock"<<endl;
            cout << "2. Hawk \n\n";

            cout << "Please enter the number of your choice: ";
            cin >> choice;

                 if(choice == 1){
                    cout << "\nAs you went,the cock pecked at the maize."<<endl;
                    cout << "You lost the game!"<<endl;

                 }
                 else{
                     cout<< "\nYou cross the river with the Hawk successfully!\n\n";

                     cout << "Do you want to keep both or return with one? "<<endl;
                     cout << "1. Keep both"<<endl;
                     cout << "2. Return the Maize"<<endl;
                     cout << "3. Return the Hawk\n\n";

                      cout << "Please enter the number of your choice: ";
                      cin >> choice;
                      if(choice == 2){
                            cout << "\nAs you went,the cock pecked at the maize."<<endl;
                            cout << "You lost the game!"<<endl;

                      }
                      else if(choice == 3){
                            cout << "\nAs you went,the hawk grabbed the cock."<<endl;
                            cout << "You lost the game! Try Again!"<<endl;

                      }
                      else {
                        cout << "\nNow you can go for the Cock successfully!"<<endl;
                        cout << "Congratulations you Won the Game!\n\n";
                      }
                 }
            }
            else{
                cout << "\nAs you went,the hawk grabbed the cock."<<endl;
                cout << "You lost the game!"<<endl;
            }
        }
    }
    else if(choice == 3){
            cout << "\nAs you went,the cock pecked at the maize."<<endl;
            cout << "You lost the game!"<<endl;
        }
        cout << "\n";

        cout << "Do you want to try again? "<<endl;
        cout << "1. Try again"<<endl;
        cout << "2. Exit the game\n\n";
        cout << "Please enter the number of your choice: ";
        cin >> next;
        cout<<endl;

    }while(next == 1);
    cout << "\nYou exit the game successfully!"<<endl;

    return 0;
}
